import Foundation

@main
struct MealLimitsTests {
    static func main() {
        assert(MealType.breakfast.dailyLimit == 1)
        assert(MealType.lunch.dailyLimit == 3)
        assert(MealType.dinner.dailyLimit == 3)
        assert(MealType.snack.dailyLimit == 1)
        print("Plan capacity tests passed")
    }
}
