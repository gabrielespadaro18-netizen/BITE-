import re, json
from pathlib import Path
from PIL import Image
root=Path(__file__).resolve().parents[1]/'BITE'
assets=root/'Assets.xcassets'
source=(root/'WorldTableData.swift').read_text()
ids=set(re.findall(r'WTRecipe\s*\(\s*id:\s*"([^\"]+)"',source))
ids|={x['id'] for x in json.loads((root/'simple_recipes.json').read_text())}
ids|={'pantry-'+id for id in re.findall(r'make\("([^"]+)"', (root/'PantryTemplates.swift').read_text())}
assert len(ids)==164,len(ids)
for id in ids:
    asset=assets/('RecipeArt_'+re.sub(r'[^A-Za-z0-9]','_',id)+'.imageset')
    obj=json.loads((asset/'Contents.json').read_text())
    img=asset/obj['images'][0]['filename']
    with Image.open(img) as im:
        assert im.size==(500,326),(id, im.size)
        im.verify()
artworks=list(assets.glob('RecipeArt_*.imageset'))
assert len(artworks)==182,len(artworks)
print('Artwork coverage: 164/164 bundled recipes + 18 Airtable-only = 182 illustrated recipes')
