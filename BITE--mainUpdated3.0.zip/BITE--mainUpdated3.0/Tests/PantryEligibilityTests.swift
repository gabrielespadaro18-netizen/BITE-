import Foundation

@main
struct PantryEligibilityTests {
    static func main() {
        assert(PantryEligibility.canCook(ingredients: ["Eggs", "Tomatoes"], available: ["Egg", "Tomato"]))
        assert(!PantryEligibility.canCook(ingredients: ["Egg", "Tomato", "Rice"], available: ["Egg", "Tomato"]))
        assert(!PantryEligibility.canCook(ingredients: ["Chicken breast"], available: ["Chicken stock"]))
        assert(!PantryEligibility.canCook(ingredients: ["Almond milk"], available: ["Milk"]))
        assert(!PantryEligibility.canCook(ingredients: [], available: ["Eggs"]))
        assert(!PantryEligibility.canCook(ingredients: ["Rice"], available: []))
        assert(PantryEligibility.canCook(ingredients: ["Tomatoes"], available: ["Tomato", "Egg"]))
        print("Pantry strict matching tests passed")
    }
}
