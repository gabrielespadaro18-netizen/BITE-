# BITE! — Pantry, My Plan, Receipt, Recipe Artwork (5 November 2026)

## Changes

1. **Cook with what you have** — Users can check/uncheck foods in Pantry. Only recipes with a nonempty list of ingredients **all** matched to selected, positive-stock pantry entries are shown. The former “missing 1–2 ingredients” section was removed from this flow. Ingredient matching is deliberately conservative and does not substitute gluten-free varieties or plant milk for other products. Recipe creation with arbitrary ingredients is still available separately under Recipes → My own recipe.
2. **My Plan** — Breakfast and Snack accept one recipe per day each; Lunch and Dinner accept three each. The Add button disappears at capacity and `AppState.addToPlan` enforces the same limits for all call sites (including adding from recipe details and weekly planning). Existing legacy plans already above these limits are not automatically deleted.
3. **Pantry** — The existing Add Food action has been relabeled **Scan / Add Food**, with a document scanning icon; tapping it retains the two choices: scan a receipt and enter food manually.
4. **Recipe visuals** — 182 original, procedurally drawn **food illustrations** were generated and bundled as individual image sets in `Assets.xcassets` (164 local recipes plus 18 Airtable-only recipes). `RecipeImage` loads local art first, offline. New personal recipes and unknown future Airtable IDs retain a visible gradient/emoji fallback. No third-party photographs, scraping, or external image licenses are involved. **These are illustrations, not photos of the recipes.** The artwork is new to this delivery, and the project owner may use it in BITE!. No external photo attribution is required.

## Tests and limitations

Run `bash Tests/run-tests.sh` on a machine with Swift, Node, and Python with Pillow. Tests cover receipt parsing, existing recipe catalog, profile migration, backend, strict ingredient matching, daily meal limits, and 182 artwork image sets. `swiftc -frontend -parse BITE/*.swift` and `plutil -lint BITE.xcodeproj/project.pbxproj` also pass in this environment.

**Not executed:** `xcodebuild`, iOS Simulator, camera capture, UI interaction tests, network Airtable sync, accessibility layout on devices. These require macOS + Xcode and actual simulator/device test sessions. This environment cannot assert a complete compiled/running iOS app. Verify on iPhone 17 iOS 27 and with small screen / Dynamic Type before release.

**Stock quantities:** Pantry stores integer counts but most recipe amounts use free-form strings (grams, cups, etc.). The strict check verifies **ingredient presence**, not sufficient grams/units or nutritional safety. It is not a substitute for checking package labels or cooking quantities.

**File integration:** `PantryEligibility.swift` is included in `BITE.xcodeproj` Compile Sources; assets are included by the existing `Assets.xcassets` build phase. No app model migration is required.
